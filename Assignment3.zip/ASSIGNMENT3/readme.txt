Brian Shaginaw : 260368016
Zahra Ghassemi : 260362867

My GetInt from assignment 2 can only handle integers up to 256, so don't input values larger than that.

We couldn't get CG working at all, but everything else should be there. GAPI.asm is unrunnable on its own: it is only provided for completeness' sake. ASS3.asm contains all of the GAPI code and will run all the GAPI commands. ASS3.asm draws a circle of points to the point specified by the user, and a smiley face to the left with drawpixel.